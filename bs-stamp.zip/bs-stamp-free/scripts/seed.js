// Run this ONCE after you've deployed and created your Firestore database, to load
// your real product, category, and back-office data into it.
//
// Setup (from the bs-stamp project root):
//   cd scripts
//   npm install
//   Download a service account key: Firebase Console → Project Settings → Service Accounts
//     → Generate new private key → save it as scripts/service-account.json
//     (this file is already in .gitignore — never commit it)
//   node seed.js
//
// It's safe to run more than once for products/categories (it checks for existing data
// and skips re-seeding if the collections aren't empty), but back office quantities
// will NOT be re-seeded if you've already added any manually.

const admin = require("firebase-admin");
const fs = require("fs");
const path = require("path");

const serviceAccountPath = path.join(__dirname, "service-account.json");
if (!fs.existsSync(serviceAccountPath)) {
  console.error("\nMissing scripts/service-account.json — see the instructions at the top of seed.js.\n");
  process.exit(1);
}

admin.initializeApp({
  credential: admin.credential.cert(require(serviceAccountPath)),
});
const db = admin.firestore();

function loadJson(relPath) {
  return JSON.parse(fs.readFileSync(path.join(__dirname, "..", relPath), "utf8"));
}

async function seedCollection(collectionName, records, label) {
  const existing = await db.collection(collectionName).limit(1).get();
  if (!existing.empty) {
    console.log(`Skipping ${label}: "${collectionName}" already has data.`);
    return;
  }
  const batchSize = 400; // Firestore batch limit is 500 writes
  for (let i = 0; i < records.length; i += batchSize) {
    const batch = db.batch();
    records.slice(i, i + batchSize).forEach((rec) => {
      const ref = db.collection(collectionName).doc();
      batch.set(ref, rec);
    });
    await batch.commit();
  }
  console.log(`Seeded ${records.length} ${label} into "${collectionName}".`);
}

(async () => {
  const products = loadJson("data/seed-products.json");
  const categories = loadJson("data/seed-categories.json");
  const backoffice = loadJson("data/seed-backoffice.json");

  await seedCollection("products", products, "active products");
  await seedCollection("categories", categories, "categories");
  await seedCollection("backoffice", backoffice, "back-office items");

  console.log("\nDone. Open your app — your real stock should be there.");
  process.exit(0);
})().catch((err) => {
  console.error(err);
  process.exit(1);
});
