const { onSchedule } = require("firebase-functions/v2/scheduler");
const { onRequest } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

const WARN_DAYS_AHEAD = 3; // notify for anything expiring within this many days (includes already-expired)

function isoDateDaysFromNow(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

async function findExpiringItems() {
  const cutoff = isoDateDaysFromNow(WARN_DAYS_AHEAD);

  const prodSnap = await db.collection("products")
    .where("isDeleted", "==", false)
    .where("expiryDate", "<=", cutoff)
    .get();

  const products = prodSnap.docs
    .map(d => d.data())
    .filter(p => !p.isSoldOut && !p.returnedDate);

  const boSnap = await db.collection("backoffice").get();
  const backoffice = boSnap.docs
    .map(d => d.data())
    .filter(b => b.expiryDate && b.expiryDate <= cutoff);

  return { products, backoffice };
}

async function sendPushToAllTokens(title, body) {
  const tokenSnap = await db.collection("fcmTokens").get();
  if (tokenSnap.empty) {
    console.log("No registered devices — skipping push.");
    return { sent: 0, removed: 0 };
  }
  const tokens = tokenSnap.docs.map(d => d.id);

  const message = {
    notification: { title, body },
    tokens,
  };

  const response = await admin.messaging().sendEachForMulticast(message);

  // Clean up tokens that are no longer valid (app uninstalled, permissions revoked, etc.)
  const batch = db.batch();
  let removed = 0;
  response.responses.forEach((res, i) => {
    if (!res.success) {
      const code = res.error && res.error.code;
      if (code === "messaging/invalid-registration-token" || code === "messaging/registration-token-not-registered") {
        batch.delete(db.collection("fcmTokens").doc(tokens[i]));
        removed++;
      }
    }
  });
  if (removed > 0) await batch.commit();

  return { sent: response.successCount, removed };
}

async function runExpiryCheck() {
  const { products, backoffice } = await findExpiringItems();
  const total = products.length + backoffice.length;

  if (total === 0) {
    console.log("Expiry check ran — nothing within the warning window.");
    return { total: 0 };
  }

  const names = [...products.map(p => p.productName), ...backoffice.map(b => b.name)].slice(0, 4);
  const preview = names.join(", ") + (total > names.length ? `, +${total - names.length} more` : "");
  const title = total === 1 ? "1 item needs attention" : `${total} items need attention`;
  const body = `Expiring within ${WARN_DAYS_AHEAD} days: ${preview}`;

  const result = await sendPushToAllTokens(title, body);
  console.log(`Expiry check: ${total} items flagged, pushed to ${result.sent} device(s), pruned ${result.removed} dead token(s).`);
  return { total, ...result };
}

// Runs every day at 08:00 in the timezone below — adjust to your shop's timezone.
exports.dailyExpiryCheck = onSchedule(
  { schedule: "0 8 * * *", timeZone: "Asia/Dubai" },
  async () => {
    await runExpiryCheck();
  }
);

// Manual trigger for testing: visit this function's URL (from `firebase deploy` output)
// in a browser any time you want to fire the check immediately, without waiting for 8am.
exports.testExpiryCheck = onRequest(async (req, res) => {
  const result = await runExpiryCheck();
  res.status(200).json({ ok: true, ...result });
});
