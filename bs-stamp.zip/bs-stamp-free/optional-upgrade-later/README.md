# Upgrading later: true background push notifications

Everything in this repo runs on Firebase's free Spark plan. The one thing Spark
genuinely cannot do is wake up a closed app to send it a push notification — that
requires Cloud Functions running on a schedule, and Google requires the pay-as-you-go
Blaze plan to deploy Cloud Functions at all (this is a Firebase/Google Cloud rule, not
a limitation of this codebase).

If you outgrow the "notifications only while the app is open" behavior and want a real
daily 8am push even when nobody has the app open, the code for that is sitting right
here in `functions/`, ready to go:

1. Firebase Console → Usage and billing → Modify plan → Blaze. (Blaze still has a free
   monthly quota — a single-shop app like this will very likely stay at $0.)
2. Move this `functions/` folder back to the project root (next to `public/`).
3. Add back into `firebase.json`:
   ```json
   "functions": [
     { "source": "functions", "codebase": "default", "runtime": "nodejs18" }
   ]
   ```
4. You'll also need to re-add Firebase Cloud Messaging to the frontend (get a VAPID
   key from Firebase Console → Cloud Messaging, add the messaging SDK back to
   `index.html`, and register FCM tokens client-side) so the Cloud Function has
   somewhere to actually send the push. Ask for this and it can be wired back in.
5. `firebase deploy`

Until then, the app already does the next best thing for free: it fires a real
notification (not a demo, an actual OS-level notification) every time it's opened or
brought back to the foreground, if anything's expiring within 3 days.
