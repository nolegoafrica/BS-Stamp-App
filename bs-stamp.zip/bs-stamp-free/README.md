# BS Stamp — Expiry, Returns & Back Office Tracker

A real installable PWA on Firebase's **free Spark plan** — no credit card required.
Push to GitHub, connect it to Firebase Hosting, and every future `git push` deploys
automatically.

Your real July 2026 data is already included in `data/` — 295 active in-stock products,
22 categories, and 36 back-office supply items — ready to load with one command.

---

## What's working, and the one honest tradeoff of staying free

**Fully working:** Firestore-backed data that syncs in real time across every device
that opens the link, barcode scanning (native camera API with a fallback library),
photo-proof capture on products *and* back-office items, category management with
rename/delete, the full Returns workflow, and an installable PWA with a custom install
prompt.

**The tradeoff:** Google requires the paid Blaze plan to deploy Cloud Functions at all
— that's the piece that would let a notification reach you while the app is fully
closed. Staying on the free plan, this app instead does the next best thing: it fires
a real, actual notification (not a demo — a genuine OS-level one) every time you open
the app or bring it back to the foreground, for anything expiring within 3 days. For a
shop app that gets opened several times a day, that's a legitimately useful alert, not
a placeholder. `optional-upgrade-later/README.md` has the exact steps if you ever want
to add true background push later.

**A genuine platform limit, not a bug:** iOS Safari has no automatic "install this app"
prompt at all (Apple doesn't expose that API to any website). The app already shows
manual "tap Share → Add to Home Screen" instructions to iPhone users instead — that's
the only way it can work there. Android Chrome gets the full one-tap install button.

---

## Part 1 — Create your free Firebase project

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → **Add project**.
   You do *not* need to upgrade the billing plan for anything in this guide.
2. **Build → Firestore Database → Create database** → start in **production mode** →
   pick a region close to you.
3. Gear icon → **Project settings → General → Your apps → Add app → Web (`</>`)**.
   Register it. Copy the `firebaseConfig` object it shows you.
4. Open `public/firebase-config.js` in this repo and paste your real values in, replacing
   every `REPLACE_ME`.

## Part 2 — Push this repo to GitHub

```bash
git init
git add .
git commit -m "BS Stamp — initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/bs-stamp.git
git push -u origin main
```

## Part 3 — Connect GitHub to Firebase Hosting (auto-deploy on every push)

The cleanest way to set this up is letting the Firebase CLI do it for you — it creates
the right service account *and* adds it to your GitHub repo's secrets automatically:

```bash
npm install -g firebase-tools
firebase login
```

Open `.firebaserc` in this repo and replace `REPLACE_WITH_YOUR_FIREBASE_PROJECT_ID`
with your actual project ID (Project Settings → General).

From the project root, with your repo already pushed to GitHub:

```bash
firebase init hosting:github
```

It'll ask a few questions — point it at the GitHub repo you just pushed, say **yes**
to setting up automatic builds and deploys, and **yes** to deploying on merge to `main`.
This does two things: creates a Google Cloud service account behind the scenes, and
adds it as a secret (`FIREBASE_SERVICE_ACCOUNT`) directly to your GitHub repo — you
don't have to touch either of those yourself.

That's it. From now on, every `git push` to `main` automatically redeploys your live
site via the GitHub Actions workflows already sitting in `.github/workflows/` in this
repo. You can watch it run under your GitHub repo's **Actions** tab.

*(If you'd rather not run `firebase init hosting:github` interactively, the two workflow
files are already written for you — you'd just need to manually create a service account
key in Firebase Console → Project Settings → Service Accounts, and paste its JSON as a
GitHub secret named `FIREBASE_SERVICE_ACCOUNT`, then fill in your project ID in both
workflow files where it says `REPLACE_WITH_YOUR_FIREBASE_PROJECT_ID`.)*

Also deploy the Firestore security rules once manually (the GitHub Action keeps them in
sync after this):

```bash
firebase deploy --only firestore:rules,firestore:indexes
```

## Part 4 — Load your real inventory

```bash
cd scripts
npm install
```

Firebase Console → Project Settings → **Service Accounts** → **Generate new private
key** → save the downloaded file as `scripts/service-account.json` (already in
`.gitignore` — it will never get committed).

```bash
node seed.js
```

Open your live URL (find it in Firebase Console → Hosting, or in your GitHub Action's
run log) — your 295 products, 22 categories, and 36 back-office items should be there.

## Part 5 — Try the notifications

Open the live app on your phone, tap **Enable** on the alerts banner, allow
notifications. If anything in your stock is expiring within 3 days, you should see a
real notification appear within a moment — and again every time you reopen the app.

---

## Project structure

```
bs-stamp/
├── .github/workflows/          # Auto-deploy on push to main (+ PR previews)
├── firebase.json               # Hosting + Firestore only — free Spark plan
├── .firebaserc                 # Your project ID goes here
├── firestore.rules             # ⚠️ read this — no login system is built in
├── firestore.indexes.json
├── public/                     # Everything Firebase Hosting serves
│   ├── index.html
│   ├── app.js                  # All frontend logic, incl. local notifications
│   ├── style.css
│   ├── manifest.json           # Makes the app installable
│   ├── firebase-config.js      # Your project credentials go here
│   ├── sw.js                   # Service worker: caching + notification display
│   └── icons/
├── scripts/
│   └── seed.js                 # One-time script to load your real data
├── data/                       # Your actual July 2026 inventory, as JSON
│   ├── seed-products.json      # 295 active, non-expired items
│   ├── seed-categories.json    # Your 22 real categories
│   └── seed-backoffice.json    # Your 36 real supply items
└── optional-upgrade-later/
    └── functions/              # Cloud Functions code for true background push
                                 # — needs the paid Blaze plan, see its README
```

## Security note (please read)

`firestore.rules` currently allows anyone with your link to read and write all data —
there's no login screen. That's fine while testing it yourself or sharing the link only
with staff you trust. Before handing the link out more widely, see the instructions
inside `firestore.rules` for adding anonymous authentication — a 5-minute change that
stops random internet strangers from being able to wipe your stock.
