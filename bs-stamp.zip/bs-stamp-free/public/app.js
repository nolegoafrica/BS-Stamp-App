// ---------- Firebase init ----------
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

const productsCol = db.collection('products');
const categoriesCol = db.collection('categories');
const backofficeCol = db.collection('backoffice');

let state = {
  products: [], categories: [], backoffice: [],
  tab: 'categories', selectedCategory: null
};
let quaggaRunning = false;
let pendingPhoto = null;
let deferredInstallPrompt = null;
let notifiedToday = new Set(JSON.parse(localStorage.getItem('bs-notified-'+new Date().toISOString().slice(0,10)) || '[]'));

function todayStr(){ return new Date().toISOString().slice(0,10); }
function nowStr(){ const d=new Date(); return d.toISOString().slice(0,16).replace('T',' '); }
function daysUntil(dateStr){ if(!dateStr) return 9999; const today=new Date(); today.setHours(0,0,0,0); const d=new Date(dateStr+"T00:00:00"); return Math.round((d-today)/86400000); }
function statusFor(days){
  if(days < 0) return {label:"Expired", color:"var(--clay-deep)", bg:"#f0d9d4"};
  if(days === 0) return {label:"Today", color:"var(--clay-deep)", bg:"#f0d9d4"};
  if(days <= 2) return {label:days+"d left", color:"var(--clay)", bg:"#f3ddd6"};
  if(days <= 7) return {label:days+"d left", color:"var(--amber)", bg:"#f2e3c4"};
  return {label:days+"d left", color:"var(--sage-deep)", bg:"#e2e7da"};
}
function edgeColor(days){ if(days<0) return "var(--clay-deep)"; if(days<=2) return "var(--clay)"; if(days<=7) return "var(--amber)"; return "var(--sage)"; }
function showToast(msg){ const t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2400); }
function escapeHtml(s){ return (s||"").toString().replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

// ---------- live data subscriptions ----------
// The app only ever displays active, non-deleted stock. Sold-out/returned items live
// in Firestore for the Returns workflow but are never shown as "in stock" anywhere.
function subscribeAll(){
  productsCol.where('isDeleted','==', false).onSnapshot(snap=>{
    state.products = snap.docs.map(d=>({id:d.id, ...d.data()}));
    render();
    checkAndNotify();
  }, err=>{ console.error(err); showToast("Couldn't load products — check Firestore rules/config"); });

  categoriesCol.orderBy('name').onSnapshot(snap=>{
    state.categories = snap.docs.map(d=>d.data().name);
    render();
  }, err=>console.error(err));

  backofficeCol.orderBy('name').onSnapshot(snap=>{
    state.backoffice = snap.docs.map(d=>({id:d.id, ...d.data()}));
    render();
    checkAndNotify();
  }, err=>console.error(err));
}

function activeProducts(){ return state.products.filter(i=>!i.isDeleted); }
function stockProducts(){ return activeProducts().filter(i=>!i.isSoldOut && !i.returnedDate); }

// ---------- render ----------
function render(){
  document.querySelectorAll('nav.bottom button').forEach(b=> b.classList.toggle('active', b.dataset.tab===state.tab));
  document.getElementById('fab-add').style.display = 'flex';

  const stock = stockProducts();
  const soon = stock.filter(i=>{const d=daysUntil(i.expiryDate); return d>=0 && d<=7;}).length;
  const soldOut = activeProducts().filter(i=>i.isSoldOut && !i.returnedDate).length;
  document.getElementById('stat-total').textContent = stock.length;
  document.getElementById('stat-soon').textContent = soon;
  document.getElementById('stat-soldout').textContent = soldOut;
  document.getElementById('stat-pending').textContent = soldOut;

  const main = document.getElementById('main');
  if(state.tab==='categories') main.innerHTML = state.selectedCategory ? renderCategoryItems() : renderCategoryList();
  else if(state.tab==='alerts') main.innerHTML = renderAlerts();
  else if(state.tab==='returns') main.innerHTML = renderReturns();
  else if(state.tab==='backoffice') main.innerHTML = renderBackoffice();
  attachMainHandlers();
}

function renderTagHTML(item){
  const d = daysUntil(item.expiryDate);
  const st = statusFor(d);
  return `
  <div class="tag" data-id="${item.id}">
    <div class="edge" style="background:${edgeColor(d)}"></div>
    <div class="hole"></div>
    <div class="body">
      <div class="row1">
        <div>
          <div class="name">${escapeHtml(item.productName)}</div>
          <div class="meta">${escapeHtml(item.category)}${item.barcode?' · '+escapeHtml(item.barcode):''}</div>
        </div>
        <div class="status" style="color:${st.color};background:${st.bg}">${st.label}</div>
      </div>
      <div class="row2"><span>Recv: ${item.receivingDate||'—'}</span><span>Exp: ${item.expiryDate||'—'}</span></div>
      <div class="idline">${item.productId?'ID '+escapeHtml(item.productId)+' · ':''}${item.batchId?'Batch '+escapeHtml(item.batchId)+' · ':''}${item.receiverName?'Recv by '+escapeHtml(item.receiverName):''}</div>
      ${item.expiryProof ? `<img src="${item.expiryProof}" style="max-width:100%;border-radius:10px;margin-top:10px;">` : (item.proofFileName ? `<div class="idline">📎 proof on file: ${escapeHtml(item.proofFileName)}</div>` : '')}
      ${item.isSoldOut ? `<div class="badge-soldout">Sold out ${item.soldOutDate?('· '+item.soldOutDate):''}</div>` : ''}
      <div class="actions">
        <button data-act="edit">Edit</button>
        ${!item.isSoldOut ? `<button data-act="soldout">Mark sold out</button>` : ''}
        ${!item.returnedDate ? `<button data-act="return">Process return</button>` : ''}
        <button data-act="del">Delete</button>
      </div>
    </div>
  </div>`;
}

function countInCategory(cat){ return stockProducts().filter(i=>i.category===cat).length; }

function renderCategoryList(){
  const stock = stockProducts();
  const upcoming = [...stock].sort((a,b)=>daysUntil(a.expiryDate)-daysUntil(b.expiryDate)).slice(0,3);
  let html = '';
  if(upcoming.length){
    html += `<div class="section-title">Needs attention</div>`;
    html += upcoming.map(renderTagHTML).join('');
  }
  html += `<div class="section-title" style="margin-top:${upcoming.length?26:4}px;">Categories</div>`;
  if(!state.categories.length){
    html += `<div class="empty"><div class="big">No categories yet</div><div class="small">Tap + to add one.</div></div>`;
  } else {
    html += state.categories.map(c=>`
      <div class="cat-row" data-cat="${escapeHtml(c)}">
        <div class="cname">${escapeHtml(c)}</div>
        <div class="ccount">${countInCategory(c)} in stock</div>
        <button class="icon-btn" data-catact="rename" data-cat="${escapeHtml(c)}" title="Rename">✎</button>
        <button class="icon-btn" data-catact="delete" data-cat="${escapeHtml(c)}" title="Delete">🗑</button>
      </div>`).join('');
  }
  return html;
}

function renderCategoryItems(){
  const cat = state.selectedCategory;
  const items = stockProducts().filter(i=>i.category===cat).sort((a,b)=>daysUntil(a.expiryDate)-daysUntil(b.expiryDate));
  let html = `<div class="section-title"><span class="back-arrow" id="cat-back">←</span> ${escapeHtml(cat)}</div>`;
  if(!items.length) html += `<div class="empty"><div class="big">Nothing in stock here</div><div class="small">Tap + to add an item to ${escapeHtml(cat)}.</div></div>`;
  else html += items.map(renderTagHTML).join('');
  return html;
}

function renderAlerts(){
  const urgent = stockProducts().filter(i=>daysUntil(i.expiryDate)<=7).sort((a,b)=>daysUntil(a.expiryDate)-daysUntil(b.expiryDate));
  let html = `<div class="section-title">Expiring within 7 days</div>`;
  if(!urgent.length) html += `<div class="empty"><div class="big">All clear</div><div class="small">Nothing expiring soon.</div></div>`;
  else html += urgent.map(renderTagHTML).join('');
  return html;
}

function renderReturns(){
  const pending = activeProducts().filter(i=>i.isSoldOut && !i.returnedDate);
  const done = activeProducts().filter(i=>i.returnedDate).sort((a,b)=> (b.returnedDate||'').localeCompare(a.returnedDate||''));
  let html = `<div class="section-title">Pending return</div>`;
  html += pending.length ? pending.map(renderTagHTML).join('') : `<div class="empty" style="padding:30px;"><div class="big">Nothing pending</div></div>`;
  html += `<div class="section-title" style="margin-top:28px;">Completed returns</div>`;
  if(!done.length){ html += `<div class="empty" style="padding:30px;"><div class="big">No returns processed yet</div></div>`; }
  else {
    html += done.map(item=>`
      <div class="tag"><div class="edge" style="background:var(--slate)"></div><div class="hole"></div>
        <div class="body">
          <div class="row1"><div><div class="name">${escapeHtml(item.productName)}</div><div class="meta">${escapeHtml(item.category)}</div></div></div>
          <div class="idline">Returned ${item.returnedDate} · Clerk: ${escapeHtml(item.returningClerk||'—')} · Verified by: ${escapeHtml(item.verifiedBy||'—')}</div>
          ${item.expiryProof ? `<img src="${item.expiryProof}" style="max-width:100%;border-radius:10px;margin-top:10px;">` : (item.proofFileName ? `<div class="idline">📎 proof on file: ${escapeHtml(item.proofFileName)}</div>` : '')}
        </div>
      </div>`).join('');
  }
  return html;
}

function renderBackoffice(){
  let html = `<div class="section-title">Back office supplies</div>`;
  if(!state.backoffice.length) html += `<div class="empty"><div class="big">Nothing tracked yet</div><div class="small">Tap + to add a supply item.</div></div>`;
  else {
    html += [...state.backoffice].sort((a,b)=>{
      const da = daysUntil(a.expiryDate), db_ = daysUntil(b.expiryDate);
      return da - db_;
    }).map(b=>{
      const hasExp = !!b.expiryDate;
      const d = hasExp ? daysUntil(b.expiryDate) : null;
      const st = hasExp ? statusFor(d) : null;
      return `
      <div class="bo-row" data-id="${b.id}">
        <div class="bname"><div class="n">${escapeHtml(b.name)}</div><div class="u">Updated ${escapeHtml(b.lastUpdated||'')}${hasExp ? ' · Exp '+escapeHtml(b.expiryDate) : ' · No expiry set'}</div></div>
        ${hasExp ? `<div class="bexp" style="color:${st.color};background:${st.bg}">${st.label}</div>` : ''}
        <div class="bo-stepper">
          <button data-boact="minus">−</button>
          <div class="qn">${b.quantity}</div>
          <button data-boact="plus">+</button>
        </div>
        <button class="del" data-boact="del">✕</button>
        <button class="secondary-btn" style="width:auto;margin-top:0;padding:8px 12px;font-size:12.5px;" data-boact="edit">Edit / add proof</button>
        ${b.proofPhotoUrl ? `<div class="bo-proof"><img src="${b.proofPhotoUrl}"></div>` : (b.proofFileName ? `<div class="idline" style="width:100%;">📎 proof on file: ${escapeHtml(b.proofFileName)}</div>` : '')}
      </div>`;
    }).join('');
  }
  return html;
}

// ---------- nav ----------
document.querySelectorAll('nav.bottom button').forEach(btn=>{
  btn.addEventListener('click', ()=>{ state.tab = btn.dataset.tab; state.selectedCategory = null; render(); });
});

function attachMainHandlers(){
  document.querySelectorAll('.cat-row').forEach(row=>{
    row.addEventListener('click', (e)=>{
      if(e.target.closest('button')) return;
      state.selectedCategory = row.dataset.cat; render();
    });
  });
  document.querySelectorAll('[data-catact]').forEach(b=>{
    b.addEventListener('click', (e)=>{
      e.stopPropagation();
      const cat = b.dataset.cat;
      if(b.dataset.catact === 'delete') deleteCategory(cat);
      else if(b.dataset.catact === 'rename') openRenameCategorySheet(cat);
    });
  });
  const backArrow = document.getElementById('cat-back');
  if(backArrow) backArrow.addEventListener('click', ()=>{ state.selectedCategory = null; render(); });

  document.querySelectorAll('.tag[data-id]').forEach(tag=>{
    const id = tag.dataset.id;
    tag.querySelectorAll('button[data-act]').forEach(b=>{
      b.addEventListener('click', (e)=>{
        e.stopPropagation();
        const act = b.dataset.act;
        if(act==='del') deleteProduct(id);
        else if(act==='edit') openAddSheet(state.products.find(i=>i.id===id));
        else if(act==='soldout') markSoldOut(id);
        else if(act==='return') openReturnSheet(id);
      });
    });
  });

  document.querySelectorAll('.bo-row').forEach(row=>{
    const id = row.dataset.id;
    row.querySelectorAll('[data-boact]').forEach(b=>{
      b.addEventListener('click', ()=>{
        const act = b.dataset.boact;
        const item = state.backoffice.find(x=>x.id===id);
        if(act==='plus') backofficeCol.doc(id).update({ quantity: (item.quantity||0)+1, lastUpdated: nowStr() });
        else if(act==='minus') backofficeCol.doc(id).update({ quantity: Math.max(0,(item.quantity||0)-1), lastUpdated: nowStr() });
        else if(act==='del') backofficeCol.doc(id).delete().then(()=>showToast("Removed"));
        else if(act==='edit') openEditBackofficeSheet(item);
      });
    });
  });
}

function deleteProduct(id){ productsCol.doc(id).update({ isDeleted:true }).then(()=>showToast("Item removed")); }
function markSoldOut(id){ productsCol.doc(id).update({ isSoldOut:true, soldOutDate: todayStr() }).then(()=>showToast("Marked sold out")); }

function deleteCategory(cat){
  if(countInCategory(cat) > 0){ showToast("Move or delete its items first"); return; }
  categoriesCol.where('name','==',cat).get().then(snap=>{
    const batch = db.batch();
    snap.forEach(doc=>batch.delete(doc.ref));
    return batch.commit();
  }).then(()=>{
    if(state.selectedCategory === cat) state.selectedCategory = null;
    showToast("Category removed");
  });
}

// ---------- sheets ----------
const backdrop = document.getElementById('sheet-backdrop');
const sheetContent = document.getElementById('sheet-content');
function closeSheet(){ stopScanner(); backdrop.classList.remove('open'); pendingPhoto=null; }
backdrop.addEventListener('click', (e)=>{ if(e.target===backdrop) closeSheet(); });

function openRenameCategorySheet(cat){
  sheetContent.innerHTML = `
    <h3>Rename category</h3>
    <div class="field"><label>Category name</label><input type="text" id="f-catname" value="${escapeHtml(cat)}"></div>
    <button class="primary-btn" id="btn-save-catname">Save</button>
    <button class="secondary-btn" id="btn-cancel-catname" type="button">Cancel</button>
  `;
  backdrop.classList.add('open');
  document.getElementById('btn-cancel-catname').addEventListener('click', closeSheet);
  document.getElementById('btn-save-catname').addEventListener('click', async ()=>{
    const newName = document.getElementById('f-catname').value.trim();
    if(!newName){ showToast("Enter a name"); return; }
    if(newName !== cat && state.categories.some(c=>c.toLowerCase()===newName.toLowerCase())){ showToast("That category already exists"); return; }
    const snap = await categoriesCol.where('name','==',cat).get();
    const batch = db.batch();
    snap.forEach(doc=>batch.update(doc.ref, {name:newName}));
    const prodSnap = await productsCol.where('category','==',cat).get();
    prodSnap.forEach(doc=>batch.update(doc.ref, {category:newName}));
    await batch.commit();
    if(state.selectedCategory === cat) state.selectedCategory = newName;
    closeSheet();
    showToast("Category renamed");
  });
}

function openAddCategorySheet(){
  sheetContent.innerHTML = `
    <h3>Add category</h3>
    <div class="field"><label>Category name</label><input type="text" id="f-catname" placeholder="e.g. New Supplier"></div>
    <button class="primary-btn" id="btn-save-catname">Add category</button>
    <button class="secondary-btn" id="btn-cancel-catname" type="button">Cancel</button>
  `;
  backdrop.classList.add('open');
  document.getElementById('btn-cancel-catname').addEventListener('click', closeSheet);
  document.getElementById('btn-save-catname').addEventListener('click', async ()=>{
    const name = document.getElementById('f-catname').value.trim();
    if(!name){ showToast("Enter a name"); return; }
    if(state.categories.some(c=>c.toLowerCase()===name.toLowerCase())){ showToast("That category already exists"); return; }
    await categoriesCol.add({ name });
    closeSheet();
    showToast("Category added");
  });
}

function openAddBackofficeSheet(){
  sheetContent.innerHTML = `
    <h3>Add supply item</h3>
    <div class="field"><label>Item name</label><input type="text" id="f-boname" placeholder="e.g. Cocoa powder"></div>
    <div class="field"><label>Starting quantity</label><input type="number" id="f-boqty" value="1" min="0"></div>
    <div class="field"><label>Expiry date (optional)</label><input type="date" id="f-boexp"></div>
    <div class="field"><label>Proof photo (optional)</label>
      <div class="photo-box">
        <input type="file" id="f-photo" accept="image/*" capture="environment" style="width:100%;">
        <div id="photo-preview"></div>
      </div>
    </div>
    <button class="primary-btn" id="btn-save-bo">Add</button>
    <button class="secondary-btn" id="btn-cancel-bo" type="button">Cancel</button>
  `;
  pendingPhoto = null;
  backdrop.classList.add('open');
  document.getElementById('f-photo').addEventListener('change', (e)=> handlePhotoCapture(e, 'photo-preview'));
  document.getElementById('btn-cancel-bo').addEventListener('click', closeSheet);
  document.getElementById('btn-save-bo').addEventListener('click', async ()=>{
    const name = document.getElementById('f-boname').value.trim();
    const qty = parseInt(document.getElementById('f-boqty').value) || 0;
    const exp = document.getElementById('f-boexp').value || null;
    if(!name){ showToast("Enter a name"); return; }
    await backofficeCol.add({ name, quantity:qty, expiryDate: exp, lastUpdated: nowStr(), proofPhotoUrl: pendingPhoto, proofFileName: null });
    closeSheet();
    showToast("Added to back office");
  });
}

function openEditBackofficeSheet(item){
  pendingPhoto = item.proofPhotoUrl || null;
  sheetContent.innerHTML = `
    <h3>Edit — ${escapeHtml(item.name)}</h3>
    <div class="field"><label>Item name</label><input type="text" id="f-boname" value="${escapeHtml(item.name)}"></div>
    <div class="field"><label>Quantity</label><input type="number" id="f-boqty" value="${item.quantity}" min="0"></div>
    <div class="field"><label>Expiry date (optional)</label><input type="date" id="f-boexp" value="${item.expiryDate||''}"></div>
    <div class="field"><label>Proof photo (optional)</label>
      <div class="photo-box">
        <input type="file" id="f-photo" accept="image/*" capture="environment" style="width:100%;">
        <div id="photo-preview">${item.proofPhotoUrl?`<img src="${item.proofPhotoUrl}">`:''}</div>
      </div>
    </div>
    <button class="primary-btn" id="btn-save-bo">Save changes</button>
    <button class="secondary-btn" id="btn-cancel-bo" type="button">Cancel</button>
  `;
  backdrop.classList.add('open');
  document.getElementById('f-photo').addEventListener('change', (e)=> handlePhotoCapture(e, 'photo-preview'));
  document.getElementById('btn-cancel-bo').addEventListener('click', closeSheet);
  document.getElementById('btn-save-bo').addEventListener('click', async ()=>{
    const name = document.getElementById('f-boname').value.trim();
    const qty = parseInt(document.getElementById('f-boqty').value) || 0;
    const exp = document.getElementById('f-boexp').value || null;
    if(!name){ showToast("Enter a name"); return; }
    await backofficeCol.doc(item.id).update({ name, quantity:qty, expiryDate: exp, lastUpdated: nowStr(), proofPhotoUrl: pendingPhoto });
    closeSheet();
    showToast("Saved");
  });
}

document.getElementById('fab-add').addEventListener('click', ()=>{
  if(state.tab === 'categories'){
    if(state.selectedCategory) openAddSheet(null, state.selectedCategory);
    else openAddCategorySheet();
  } else if(state.tab === 'backoffice'){
    openAddBackofficeSheet();
  } else {
    openAddSheet();
  }
});

function openAddSheet(existing, presetCategory){
  stopScanner();
  pendingPhoto = null;
  const isEdit = !!existing;
  const item = existing || {id:null, productName:'', category: presetCategory || (state.categories[0]||''), barcode:'', productId:'', batchId:'', batchDate:'', receivingDate:todayStr(), expiryDate:defaultExpiry(), receiverName:'', expiryProof:null};
  if(isEdit) pendingPhoto = item.expiryProof || null;
  const catOptions = state.categories.length ? state.categories : [item.category].filter(Boolean);
  sheetContent.innerHTML = `
    <h3>${isEdit?'Edit item':'Receive new item'}</h3>
    <div id="scanner-view" style="display:none;"></div>
    <div class="scan-hint" id="scan-hint" style="display:none;">Point your camera at the barcode</div>
    ${isEdit?'':`<button class="secondary-btn" id="btn-scan" type="button">📷 Scan barcode</button>`}
    <div class="field" style="margin-top:16px;"><label>Product name</label><input type="text" id="f-name" value="${escapeHtml(item.productName)}" placeholder="e.g. Stick chocolate"></div>
    <div class="field"><label>Category</label><select id="f-cat">${catOptions.map(c=>`<option ${c===item.category?'selected':''}>${escapeHtml(c)}</option>`).join('')}</select></div>
    <div class="field"><label>Barcode</label><input type="text" id="f-barcode" value="${escapeHtml(item.barcode)}"></div>
    <div class="field-row">
      <div class="field"><label>Product ID</label><input type="text" id="f-pid" value="${escapeHtml(item.productId)}"></div>
      <div class="field"><label>Batch ID</label><input type="text" id="f-bid" value="${escapeHtml(item.batchId)}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Receiving date</label><input type="date" id="f-recv" value="${item.receivingDate}"></div>
      <div class="field"><label>Batch date</label><input type="date" id="f-bdate" value="${item.batchDate||''}"></div>
    </div>
    <div class="field"><label>Expiry date</label><input type="date" id="f-exp" value="${item.expiryDate}"></div>
    <div class="field"><label>Receiver name</label><input type="text" id="f-receiver" value="${escapeHtml(item.receiverName)}" placeholder="Who received this stock"></div>
    <div class="field"><label>Proof photo (optional)</label>
      <div class="photo-box">
        <input type="file" id="f-photo" accept="image/*" capture="environment" style="width:100%;">
        <div id="photo-preview">${item.expiryProof?`<img src="${item.expiryProof}">`:''}</div>
      </div>
    </div>
    <button class="primary-btn" id="btn-save">${isEdit?'Save changes':'Add to stock'}</button>
    ${isEdit?`<button class="secondary-btn" id="btn-cancel" type="button">Cancel</button>`:''}
  `;
  backdrop.classList.add('open');
  const cancelBtn = document.getElementById('btn-cancel');
  if(cancelBtn) cancelBtn.addEventListener('click', closeSheet);
  document.getElementById('f-photo').addEventListener('change', (e)=> handlePhotoCapture(e, 'photo-preview'));

  const scanBtn = document.getElementById('btn-scan');
  if(scanBtn){
    scanBtn.addEventListener('click', ()=>{
      const view = document.getElementById('scanner-view'); const hint = document.getElementById('scan-hint');
      view.style.display='block'; hint.style.display='block'; scanBtn.textContent='Stop scanning';
      scanBtn.onclick = ()=>{ stopScanner(); view.style.display='none'; hint.style.display='none'; scanBtn.style.display='none'; };
      startScanner(view);
    });
  }

  document.getElementById('btn-save').addEventListener('click', async ()=>{
    const productName = document.getElementById('f-name').value.trim();
    const category = document.getElementById('f-cat').value;
    const barcode = document.getElementById('f-barcode').value.trim();
    const productId = document.getElementById('f-pid').value.trim();
    const batchId = document.getElementById('f-bid').value.trim();
    const batchDate = document.getElementById('f-bdate').value;
    const receivingDate = document.getElementById('f-recv').value;
    const expiryDate = document.getElementById('f-exp').value;
    const receiverName = document.getElementById('f-receiver').value.trim();
    if(!productName || !expiryDate){ showToast("Add a product name and expiry date"); return; }
    if(isEdit){
      await productsCol.doc(item.id).update({productName,category,barcode,productId,batchId,batchDate,receivingDate,expiryDate,receiverName, expiryProof: pendingPhoto});
    } else {
      await productsCol.add({productName,category,barcode,productId,batchId,batchDate,receivingDate,expiryDate,receiverName, expiryProof: pendingPhoto, proofFileName:null, isSoldOut:false, soldOutDate:null, returningClerk:null, returnedDate:null, verifiedBy:null, isDeleted:false});
    }
    closeSheet();
    showToast(isEdit?"Item updated":"Added to stock");
  });
}

function defaultExpiry(){ const d=new Date(); d.setDate(d.getDate()+14); return d.toISOString().slice(0,10); }

function handlePhotoCapture(e, previewId){
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = (ev)=>{
    const img = new Image();
    img.onload = ()=>{
      const canvas = document.createElement('canvas');
      const maxW = 600;
      const scale = Math.min(1, maxW/img.width);
      canvas.width = img.width*scale; canvas.height = img.height*scale;
      canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
      pendingPhoto = canvas.toDataURL('image/jpeg', 0.72);
      document.getElementById(previewId).innerHTML = `<img src="${pendingPhoto}">`;
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
}

function openReturnSheet(id){
  const item = state.products.find(i=>i.id===id);
  pendingPhoto = item.expiryProof || null;
  sheetContent.innerHTML = `
    <h3>Process return — ${escapeHtml(item.productName)}</h3>
    <div class="field"><label>Returning clerk</label><input type="text" id="f-clerk" value="${escapeHtml(item.returningClerk||'')}"></div>
    <div class="field"><label>Returned date</label><input type="date" id="f-rdate" value="${item.returnedDate||todayStr()}"></div>
    <div class="field"><label>Verified by</label><input type="text" id="f-verifier" value="${escapeHtml(item.verifiedBy||'')}"></div>
    <div class="field"><label>Expiry proof photo</label>
      <div class="photo-box">
        <input type="file" id="f-photo" accept="image/*" capture="environment" style="width:100%;">
        <div id="photo-preview">${item.expiryProof?`<img src="${item.expiryProof}">`:''}</div>
      </div>
    </div>
    <button class="primary-btn" id="btn-save-return">Save return</button>
    <button class="secondary-btn" id="btn-cancel-return" type="button">Cancel</button>
  `;
  backdrop.classList.add('open');
  document.getElementById('btn-cancel-return').addEventListener('click', closeSheet);
  document.getElementById('f-photo').addEventListener('change', (e)=> handlePhotoCapture(e, 'photo-preview'));
  document.getElementById('btn-save-return').addEventListener('click', async ()=>{
    const returningClerk = document.getElementById('f-clerk').value.trim();
    const returnedDate = document.getElementById('f-rdate').value || todayStr();
    const verifiedBy = document.getElementById('f-verifier').value.trim();
    await productsCol.doc(id).update({ returningClerk, returnedDate, verifiedBy, expiryProof: pendingPhoto });
    closeSheet();
    showToast("Return recorded");
  });
}

// ---------- barcode scanning: native BarcodeDetector first, Quagga fallback ----------
async function startScanner(target){
  if('BarcodeDetector' in window){
    try{
      const formats = await BarcodeDetector.getSupportedFormats();
      const detector = new BarcodeDetector({ formats: formats.filter(f=>['ean_13','ean_8','upc_a','upc_e','code_128'].includes(f)) });
      const video = document.createElement('video');
      video.setAttribute('playsinline','');
      video.style.width = '100%';
      target.innerHTML = '';
      target.appendChild(video);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      video.srcObject = stream;
      await video.play();
      quaggaRunning = { native:true, stream };
      const tick = async ()=>{
        if(!quaggaRunning) return;
        try{
          const codes = await detector.detect(video);
          if(codes.length){
            const code = codes[0].rawValue;
            stopScanner();
            const bc = document.getElementById('f-barcode'); if(bc) bc.value = code;
            const hint = document.getElementById('scan-hint'); if(hint) hint.textContent = "Looking up "+code+"…";
            await lookupBarcode(code);
            return;
          }
        }catch(e){ /* keep trying */ }
        if(quaggaRunning) requestAnimationFrame(tick);
      };
      tick();
      return;
    }catch(e){
      console.warn("Native BarcodeDetector failed, falling back to Quagga:", e);
    }
  }
  startQuagga(target);
}

function startQuagga(target){
  if(typeof Quagga==='undefined'){ showToast("Scanner unavailable on this browser"); return; }
  Quagga.init({ inputStream:{name:"Live",type:"LiveStream",target,constraints:{facingMode:"environment"}}, decoder:{readers:["ean_reader","ean_8_reader","upc_reader","upc_e_reader","code_128_reader"]}, locate:true },
    function(err){ if(err){ showToast("Camera access needed to scan"); return; } Quagga.start(); quaggaRunning = {native:false}; });
  Quagga.offDetected();
  Quagga.onDetected(async (result)=>{
    const code = result.codeResult.code;
    stopScanner();
    const bc = document.getElementById('f-barcode'); if(bc) bc.value = code;
    const hint = document.getElementById('scan-hint'); if(hint) hint.textContent = "Looking up "+code+"…";
    await lookupBarcode(code);
  });
}

function stopScanner(){
  if(!quaggaRunning) return;
  if(quaggaRunning.native){
    try{ quaggaRunning.stream.getTracks().forEach(t=>t.stop()); }catch(e){}
  } else {
    try{ Quagga.stop(); }catch(e){}
  }
  quaggaRunning = false;
  const view = document.getElementById('scanner-view'); const hint = document.getElementById('scan-hint');
  if(view) view.style.display='none'; if(hint) hint.style.display='none';
}

async function lookupBarcode(code){
  try{
    const res = await fetch(`https://world.openfoodfacts.org/api/v2/product/${code}.json`);
    const data = await res.json();
    if(data.status===1 && data.product){
      const nameField = document.getElementById('f-name');
      if(nameField && !nameField.value) nameField.value = data.product.product_name || data.product.generic_name || '';
      showToast("Product found — check the details");
    } else showToast("Barcode captured — enter name manually");
  }catch(e){ showToast("Couldn't reach lookup service — barcode still saved"); }
}

// ---------- install prompt ----------
// iOS Safari has no beforeinstallprompt API at all (Apple's restriction) and no Web
// Push before a PWA is added to the Home Screen — so it needs manual instructions instead.
const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
if(isIOS && !isStandalone){
  const bar = document.getElementById('install-bar');
  bar.innerHTML = `📲 On iPhone: tap the Share icon, then "Add to Home Screen" to install. <button class="dismiss" id="install-dismiss">✕</button>`;
  bar.classList.add('show');
  document.getElementById('install-dismiss').addEventListener('click', ()=> bar.classList.remove('show'));
}

window.addEventListener('beforeinstallprompt', (e)=>{
  e.preventDefault();
  deferredInstallPrompt = e;
  document.getElementById('install-bar').classList.add('show');
});
document.getElementById('install-btn').addEventListener('click', async ()=>{
  if(!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  document.getElementById('install-bar').classList.remove('show');
});
document.getElementById('install-dismiss').addEventListener('click', ()=>{
  document.getElementById('install-bar').classList.remove('show');
});
window.addEventListener('appinstalled', ()=>{
  document.getElementById('install-bar').classList.remove('show');
  showToast("Installed! Find BS Stamp on your home screen.");
});

// ---------- notifications: real, local, no backend required ----------
// True background push (app fully closed) needs a server to wake it up at the right
// time, which on Firebase means Cloud Functions — Blaze plan only, see README. This
// path instead fires a REAL notification (via the service worker, so it still shows
// even if the tab isn't focused) every time the app is open or brought back to the
// foreground, checking Firestore for anything expiring within 3 days that hasn't
// already been flagged today. For a shop app opened several times a day, that's a
// genuinely useful alert, not a placeholder.
const NOTIFY_WINDOW_DAYS = 3;

function markNotified(ids){
  ids.forEach(id => notifiedToday.add(id));
  localStorage.setItem('bs-notified-'+todayStr(), JSON.stringify([...notifiedToday]));
}

async function checkAndNotify(){
  if(!('Notification' in window) || Notification.permission !== 'granted') return;

  const urgentProducts = stockProducts().filter(i => daysUntil(i.expiryDate) <= NOTIFY_WINDOW_DAYS && !notifiedToday.has(i.id));
  const urgentBackoffice = state.backoffice.filter(b => b.expiryDate && daysUntil(b.expiryDate) <= NOTIFY_WINDOW_DAYS && !notifiedToday.has(b.id));
  const all = [...urgentProducts, ...urgentBackoffice];
  if(!all.length) return;

  const names = [...urgentProducts.map(p=>p.productName), ...urgentBackoffice.map(b=>b.name)].slice(0,4);
  const total = all.length;
  const title = total === 1 ? "1 item needs attention" : `${total} items need attention`;
  const body = `Expiring within ${NOTIFY_WINDOW_DAYS} days: ` + names.join(", ") + (total > names.length ? `, +${total-names.length} more` : "");

  try{
    const reg = await navigator.serviceWorker.ready;
    await reg.showNotification(title, { body, icon:'/icons/icon-192.png', badge:'/icons/icon-192.png' });
  }catch(e){
    new Notification(title, { body, icon:'/icons/icon-192.png' });
  }
  markNotified(all.map(i=>i.id));
}

document.getElementById('perm-btn').addEventListener('click', async ()=>{
  const perm = await Notification.requestPermission();
  document.getElementById('perm-bar').classList.remove('show');
  if(perm === 'granted'){ showToast("Alerts enabled"); checkAndNotify(); }
  else showToast("Alerts weren't enabled");
});
document.getElementById('perm-dismiss').addEventListener('click', ()=>{
  document.getElementById('perm-bar').classList.remove('show');
});

function initPermBar(){
  if(!('Notification' in window)) return;
  if(Notification.permission === 'default') document.getElementById('perm-bar').classList.add('show');
  else if(Notification.permission === 'granted') checkAndNotify();
}

// Re-check whenever the app comes back into view, and every 15 minutes while it's open.
document.addEventListener('visibilitychange', ()=>{ if(document.visibilityState === 'visible') checkAndNotify(); });
setInterval(checkAndNotify, 15*60*1000);

// ---------- boot ----------
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('/sw.js').then(()=>{
    subscribeAll();
    initPermBar();
  }).catch(e=>{ console.error("SW registration failed", e); subscribeAll(); });
} else {
  subscribeAll();
}
